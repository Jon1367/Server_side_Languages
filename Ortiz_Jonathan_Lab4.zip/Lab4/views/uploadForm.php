
<form enctype="multipart/form-data" action="?controller=home&action=uploadAction" method="POST">
    
    <input type="file" name="myfile">

    <input type="submit"/>


</form>