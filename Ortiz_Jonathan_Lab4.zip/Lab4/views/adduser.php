<form enctype="" action="?controller=home&action=addingUser" method="POST">
    <input type="text" name="username" placeholder="Username"/>
    <input type="password" name="password" placeholder="Password"/>

    <input type="submit"/>


</form>